﻿using System;

namespace Ojas.TimeSheet.BusinessModel
{
    public class Class1
    {
    }
}
