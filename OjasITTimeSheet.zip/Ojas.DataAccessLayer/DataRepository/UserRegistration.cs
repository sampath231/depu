﻿using System;
using System.Collections.Generic;
using System.Text;
using Ojas.DataAccessLayer.Entities;

namespace Ojas.DataAccessLayer.DataRepository
{
    public class UserRegistration : IDataRepository<Entities.Registration>
    {
        public bool Add(Registration model)
        {
            using (var dt = new Ojas.DataAccessLayer.Entities.OjasTimeSheetDBContext())
            {
                dt.Registration.Add(model);
                dt.SaveChanges();
            }
            return true;
        }
    }
}
