﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Ojas.DataAccessLayer.DataRepository
{
    public class BaseDataRepository<T> : IDataRepository<T>
    {
        public bool Add(T model)
        {
            throw new NotImplementedException();
        }
    }
}
