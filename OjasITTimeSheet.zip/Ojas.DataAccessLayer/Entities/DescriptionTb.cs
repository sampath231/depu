﻿using System;
using System.Collections.Generic;

namespace Ojas.DataAccessLayer.Entities
{
    public partial class DescriptionTb
    {
        public int DescriptionId { get; set; }
        public string Description { get; set; }
        public int? ProjectId { get; set; }
        public int? TimeSheetMasterId { get; set; }
        public DateTime? CreatedOn { get; set; }
        public int? UserId { get; set; }

        public ProjectMaster Project { get; set; }
        public TimeSheetMaster TimeSheetMaster { get; set; }
    }
}
