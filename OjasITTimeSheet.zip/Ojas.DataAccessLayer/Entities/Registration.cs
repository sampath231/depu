﻿using System;
using System.Collections.Generic;

namespace Ojas.DataAccessLayer.Entities
{
    public partial class Registration
    {
        public Registration()
        {
            AssignedRoles = new HashSet<AssignedRoles>();
            AuditTb = new HashSet<AuditTb>();
            Documents = new HashSet<Documents>();
            ExpenseAuditTb = new HashSet<ExpenseAuditTb>();
        }

        public int RegistrationId { get; set; }
        public string Name { get; set; }
        public string Mobileno { get; set; }
        public string EmailId { get; set; }
        public string Username { get; set; }
        public string Password { get; set; }
        public string ConfirmPassword { get; set; }
        public string Gender { get; set; }
        public DateTime? Birthdate { get; set; }
        public int? RoleId { get; set; }
        public DateTime? CreatedOn { get; set; }
        public string EmployeeId { get; set; }
        public DateTime? DateofJoining { get; set; }
        public int? ForceChangePassword { get; set; }

        public Roles Role { get; set; }
        public ICollection<AssignedRoles> AssignedRoles { get; set; }
        public ICollection<AuditTb> AuditTb { get; set; }
        public ICollection<Documents> Documents { get; set; }
        public ICollection<ExpenseAuditTb> ExpenseAuditTb { get; set; }
    }
}
