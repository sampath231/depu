﻿using System;
using System.Collections.Generic;

namespace Ojas.DataAccessLayer.Entities
{
    public partial class TimeSheetMaster
    {
        public TimeSheetMaster()
        {
            DescriptionTb = new HashSet<DescriptionTb>();
        }

        public int TimeSheetMasterId { get; set; }
        public DateTime? FromDate { get; set; }
        public DateTime? ToDate { get; set; }
        public int? TotalHours { get; set; }
        public int? UserId { get; set; }
        public DateTime? CreatedOn { get; set; }
        public string Comment { get; set; }
        public int? TimeSheetStatus { get; set; }

        public ICollection<DescriptionTb> DescriptionTb { get; set; }
    }
}
