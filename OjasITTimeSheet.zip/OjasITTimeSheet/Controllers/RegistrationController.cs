﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Ojas.TimeSheet.BusinessLayer;
using Ojas.TimeSheet.BusinessModel;

namespace OjasITTimeSheet.Controllers
{
    public class RegistrationController : Controller
    {
        private Ojas.TimeSheet.BusinessLayer.IRegistrationBL _businessLayer;
        public RegistrationController(IRegistrationBL businesslayer)
        {
            _businessLayer = businesslayer;
        }
        public IActionResult Index()
        {
            return View();
        }

        public IActionResult CreateAdmin()
        {
            return View();
        }

        public IActionResult CreateUser()
        {


            return View();


        }
        [HttpPost]
        public IActionResult PostUserRegistration( [FromBody] UserRegistrationModel model)
        {
            _businessLayer.RegisterUser(model);
            return Json(true);
        }
    }
}
