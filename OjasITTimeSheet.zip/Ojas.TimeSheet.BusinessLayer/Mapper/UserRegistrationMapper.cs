﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Ojas.TimeSheet.BusinessLayer.Mapper
{
    public class UserRegistrationMapper
    {
        public static  DataAccessLayer.Entities.Registration ConvertToEntites(Ojas.TimeSheet.BusinessModel.UserRegistrationModel model)
        {
            return new DataAccessLayer.Entities.Registration()
            {
                Name = model.Name,
                Password = model.Password,
                ConfirmPassword = model.ConfirmPassoword,
                CreatedOn = DateTime.Now,
                Username = model.UserName,
                EmailId = model.Email,
                Mobileno = model.MobileNumber
            };
        }
    }
}
