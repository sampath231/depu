﻿using System;

namespace Ojas.TimeSheet.BusinessLayer
{
    public class Class1
    {
    }
}
